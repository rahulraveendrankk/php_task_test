<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ansonika">
    <title>IMMOHELD</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="https://immoheld.eu/blog/wp-content/uploads/2018/10/Immoheld-Logo-white.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="<?php echo base_url(); ?>assets/img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="<?php echo base_url(); ?>assets/img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="<?php echo base_url(); ?>assets/img/apple-touch-icon-144x144-precomposed.png">
	
    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
    <link href="<?php echo base_url(); ?>assets/css/home_1.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/listing.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/product_page.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/cart.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/checkout.css" rel="stylesheet">

    <style>
    	.alert {
	padding: 15px;
	margin-bottom: 20px;
	border: 1px solid transparent;
	border-radius: 4px
}

.alert h4 {
	margin-top: 0;
	color: inherit
}

.alert .alert-link {
	font-weight: 700
}

.alert>p,
.alert>ul {
	margin-bottom: 0
}

.alert>p+p {
	margin-top: 5px
}

.alert-dismissable,
.alert-dismissible {
	padding-right: 35px
}

.alert-dismissable .close,
.alert-dismissible .close {
	position: relative;
	top: -2px;
	right: -21px;
	color: inherit
}

.alert-success {
	color: #3c763d;
	background-color: #dff0d8;
	border-color: #d6e9c6
}

.alert-success hr {
	border-top-color: #c9e2b3
}

.alert-success .alert-link {
	color: #2b542c
}

.alert-info {
	color: #31708f;
	background-color: #d9edf7;
	border-color: #bce8f1
}

.alert-info hr {
	border-top-color: #a6e1ec
}

.alert-info .alert-link {
	color: #245269
}

.alert-warning {
	color: #8a6d3b;
	background-color: #fcf8e3;
	border-color: #faebcc
}

.alert-warning hr {
	border-top-color: #f7e1b5
}

.alert-warning .alert-link {
	color: #66512c
}

.alert-danger {
	color: #a94442;
	background-color: #f2dede;
	border-color: #ebccd1
}

.alert-danger hr {
	border-top-color: #e4b9c0
}

.alert-danger .alert-link {
	color: #843534
}
	</style>

</head>

<body>
	
	<div id="page">
		
	<header class="version_1">
		<div class="layer"></div><!-- Mobile menu overlay mask -->
		<div class="main_header">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 d-lg-flex align-items-center">
						<div id="logo">
							<a href="<?php echo base_url(); ?>"><img src="https://immoheld.eu/blog/wp-content/uploads/2018/10/Immoheld-Logo-white.png" alt="" width="100" height="35"></a>
						</div>
					</div>
					<nav class="col-xl-6 col-lg-7">
						<a class="open_close" href="javascript:void(0);">
							<div class="hamburger hamburger--spin">
								<!-- <div class="hamburger-box">
									<div class="hamburger-inner"></div>
								</div> -->
							</div>
						</a>
						<!-- Mobile menu button -->
						<div class="main-menu">
							 
							<ul>
								<li>
									<a href="javascript:void(0);">&nbsp;</a>
								</li>
								<li>
									<?php //echo $this->input->cookie('fischer_cookie',true); ?>
									<!-- <a href="<?php echo base_url('Products'); ?>">Products</a> -->
								</li>
								
								<li>
									<!-- <a href="<?php echo base_url('Offers'); ?>">Offers</a> -->
								</li>
								<!-- <li>
									<a href="#0">Blog</a>
								</li> -->
							</ul>
						</div>
						<!--/main-menu -->
					</nav>
					<div class="col-xl-3 col-lg-2 d-lg-flex align-items-center justify-content-end text-end">
						 
					</div>
				</div>
				<!-- /row -->
			</div>
		</div>
		<!-- /main_header -->

		<div class="main_nav Sticky">
			<div class="container">
				<div class="row small-gutters">
					<div class="col-xl-3 col-lg-3 col-md-3">
						 
					</div>
					<div class="col-xl-12 col-lg-7 col-md-12 d-none d-md-block">

						<img src="<?php echo base_url(); ?>assets/img/sort.png" style=" cursor: pointer;width: 30px;height: 30px; margin-left:10px;" id="sortPrice">
						<div class="custom-search-input " style=" display: inline-block; width: 20%;margin-left: 100px;">
							 
							<input type="text" placeholder=" Size: From" class="filterProperties" id="fromSize" item_text="fromSize">
							<button type="submit"><i class="header-icon_search_custom"></i></button>
								  
						</div>



						<div class="custom-search-input" style=" display: inline-block;float: left;margin-left:20px;  width: 20%; ">
							 
							<input type="text" placeholder="Price: From" class="filterProperties" id="fromPrice" item_text="fromPrice">
							<button type="submit"><i class="header-icon_search_custom"></i></button>
								  
						</div>



						<div class="custom-search-input " style=" display: inline-block; width: 20%;margin-left: 10px;">
							  
							<input type="text" placeholder="To" class="filterProperties" id="toSize" item_text="toSize">
							<button type="submit"><i class="header-icon_search_custom"></i></button>
								  
						</div>



						<div class="custom-search-input" style=" display: inline-block;float: left;margin-left: 10px;  width: 20%; ">
							 
							<input type="text" placeholder=" To" class="filterProperties" id="toPrice" item_text="toPrice">
							<button type="submit"><i class="header-icon_search_custom"></i></button>
								  
						</div>

						<img src="<?php echo base_url(); ?>assets/img/sort.png" style="cursor: pointer;width: 30px;height: 30px; margin-left:10px;" id="sortSize">
					</div>
					<div class="col-xl-3 col-lg-2 col-md-3">
						<ul class="top_tools">
							<li>
								&nbsp;
							</li> 
						 
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<div class="search_mob_wp">
				<input type="text" class="form-control" placeholder="Search over 10.000 products">
				<input type="submit" class="btn_1 full-width" value="Search">
			</div>
			<!-- /search_mobile -->
		</div>
		<!-- /main_nav -->
	</header>
	<!-- /header -->
	