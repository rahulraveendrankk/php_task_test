<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class EncryptDecrypt extends CI_Model{
    public function encrypt($name){
        if($name!=""){
            $encrypt=base64_encode($name);
            $encrypt=str_replace("=","",$encrypt);
            $mdcode=md5($name);
            $mdcode1=substr($mdcode,0,12);
            $mdcode2=substr($mdcode,12,32);
            $encrypt1=substr($encrypt,0,1);
            $encrypt2=substr($encrypt,1,1);
            $encrypt3=substr($encrypt,2);
            $encrypted_value=$encrypt2.$mdcode2.$encrypt1.$mdcode1.$encrypt3;
            return $encrypted_value;
        }  else {
            return NULL;
        }
    }

    public function decrypt($name){
        if($name!=""){
            $decrypt=substr($name,21);
            $decrypt1=substr($name,0,1);
            $decrypt2=substr($decrypt,0,1);
            $decrypt3=substr($decrypt,13);
            $decrypted=$decrypt2.$decrypt1.$decrypt3;
            $decrypted_data=base64_decode($decrypted);
            return $decrypted_data;
        }  else {
            return NULL;
        }
    }
}
?>