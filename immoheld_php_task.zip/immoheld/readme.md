This is the Immoheld PHP developer role test task,

Real estate listings with search and sorting.  

Technologies used:

   PHP V8.0.1
   Codeigniter 
   Posgresql
   Jquery

Please setup the local server and create the database 'immoheld_php_task' 

After creating database please load localhost/immoheld/home/create_table to create the table and insert Test data.

after that it will redirect to the List where you can search Price from-to and sort also Size from-to and sort .
