<footer class="revealed">
	 
	</footer>
	<!--/footer-->
	</div>
	<!-- page -->
	
	<div id="toTop"></div><!-- Back to top button -->


	<!-- /add_cart_panel -->
	
	<!-- Size modal -->
	<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="size-modal" id="size-modal" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Size guide</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<p>Lorem ipsum dolor sit amet, et velit propriae invenire mea, ad nam alia intellegat. Aperiam mediocrem rationibus nec te. Tation persecuti accommodare pro te. Vis et augue legere, vel labitur habemus ocurreret ex.</p>
					<div class="table-responsive">
                                <table class="table table-striped table-sm sizes">
                                    <tbody><tr>
                                        <th scope="row">US Sizes</th>
                                        <td>6</td>
                                        <td>6,5</td>
                                        <td>7</td>
                                        <td>7,5</td>
                                        <td>8</td>
                                        <td>8,5</td>
                                        <td>9</td>
                                        <td>9,5</td>
                                        <td>10</td>
                                        <td>10,5</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Euro Sizes</th>
                                        <td>39</td>
                                        <td>39</td>
                                        <td>40</td>
                                        <td>40-41</td>
                                        <td>41</td>
                                        <td>41-42</td>
                                        <td>42</td>
                                        <td>42-43</td>
                                        <td>43</td>
                                        <td>43-44</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">UK Sizes</th>
                                        <td>5,5</td>
                                        <td>6</td>
                                        <td>6,5</td>
                                        <td>7</td>
                                        <td>7,5</td>
                                        <td>8</td>
                                        <td>8,5</td>
                                        <td>9</td>
                                        <td>9,5</td>
                                        <td>10</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Inches</th>
                                        <td>9.25"</td>
                                        <td>9.5"</td>
                                        <td>9.625"</td>
                                        <td>9.75"</td>
                                        <td>9.9375"</td>
                                        <td>10.125"</td>
                                        <td>10.25"</td>
                                        <td>10.5"</td>
                                        <td>10.625"</td>
                                        <td>10.75"</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">CM</th>
                                        <td>23,5</td>
                                        <td>24,1</td>
                                        <td>24,4</td>
                                        <td>24,8</td>
                                        <td>25,4</td>
                                        <td>25,7</td>
                                        <td>26</td>
                                        <td>26,7</td>
                                        <td>27</td>
                                        <td>27,3</td>
                                    </tr>
                                </tbody></table>
                            </div>
					<!-- /table -->
				</div>
			</div>
		</div>
	</div>
	<input type="hidden" id="price_sorted" value='0'>
	<input type="hidden" id="size_sorted" value='0'>
	<!-- COMMON SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/js/common_scripts.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
	
	<!-- SPECIFIC SCRIPTS -->  
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script rel="javascript" type="text/javascript" href="js/jquery-1.11.3.min.js"></script>

	 

	<script>
		$(".filterProperties").keyup(function(){
 			 
 				var fromPrice=$('#fromPrice').val();
 				if(fromPrice=='')
 					fromPrice=0;
 				var toPrice=$('#toPrice').val();
 				if(toPrice=='')
 					toPrice=0;

 				var fromSize=$('#fromSize').val();
 				if(fromSize=='')
 					fromSize=0;
 				var toSize=$('#toSize').val();
 				if(toSize=='')
 					toSize=0;
          		 console.log(fromPrice +'---'+ toPrice +'---'+ fromSize +'---'+ toSize);
                if(fromPrice==0 && toPrice==0 && fromSize==0 && toSize==0){
                      
 					$('.allProperties').show();

                }else{ 
 					
                    var flag=1;
                    $('.allProperties').each(function()
                    { 
                      	flag=1;
                        var itemPrice = $(this).attr('item_price'); 

                        if(fromPrice>0 && toPrice>0){
	                        if( fromPrice <= itemPrice && itemPrice <= toPrice){
	                          	flag=1; 
	                        }else{
	                        	flag=0;
	                        }  
	                             
	                    }else if(fromPrice>0 && toPrice==0){
	                    	if( fromPrice<=  itemPrice  ){
	                          	flag=1;  
	                        }else{
	                        	flag=0;  
	                        }
	                         
	                    }else if(fromPrice==0 && toPrice<0){
	                    	if(  itemPrice <= toPrice ){
	                          	flag=1; 
	                        }else{
	                        	flag=0;
	                        }
	                          
	                    }else{
	                    	flag=1;
	                    	 
	                    }

	                    // console.log(flag);

                        var itemSize = $(this).attr('item_size'); 
                        if(flag==1){
	                        if(fromSize>0 && toSize>0){
		                        if( fromSize <= itemSize && itemSize <= toSize){
		                          	flag=1;  
		                        }else{
		                        	flag=0;
		                        }  
		                             
		                    }else if(fromSize>0 && toSize==0){
		                    	if( fromSize<=  itemSize  ){
		                          	flag=1; 
		                        }else{
		                        	flag=0;  
		                        }
		                         
		                    }else if(fromSize==0 && toSize<0){
		                    	if(  itemSize <= toSize ){
		                          	flag=1; 
		                        }else{
		                        	flag=0;
		                        }
		                          
		                    }else{
		                    	flag=1;
		                    	 
		                    }
		                }

                        if(flag==0)
                        	$(this).hide();
                        else
                        	$(this).show();  
                    });
                       
                } 
            });
 
	 

		$("#sortPrice").click(function(){ 

			var sorted=$('#price_sorted').val();
			if(sorted==0){
				$('#price_sorted').val(1); 
				document.querySelectorAll(".allProperties")
			      .forEach(div => { 
			        div.style.order = div.getAttribute('item_price');
			    });
			}else{
				$('#price_sorted').val(0); 
				document.querySelectorAll(".allProperties")
			      .forEach(div => { 
			        div.style.order = -1*div.getAttribute('item_price');
			      });
			}
			     

		});

		$("#sortSize").click(function(){ 

			var sorted=$('#size_sorted').val();
			if(sorted==0){
				$('#size_sorted').val(1); 
				document.querySelectorAll(".allProperties")
			      .forEach(div => { 
			        div.style.order = div.getAttribute('item_size');
			    });
			}else{
				$('#size_sorted').val(0); 
				document.querySelectorAll(".allProperties")
			      .forEach(div => { 
			        div.style.order = -1*div.getAttribute('item_size');
			      });
			}
			     

		});
 
	</script>

</body>
</html>