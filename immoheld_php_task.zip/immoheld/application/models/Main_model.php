<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Main_model extends CI_Model { 
 
	function get_all_data($table)
    {
		$this->db->select('*');
		$this->db->from($table); 
		$query = $this->db->get();
		return $query->result();
	} 

	function create_table(){

		$this->db->query("CREATE TABLE IF NOT EXISTS properties (
			id serial PRIMARY KEY,
			name VARCHAR ( 50 )  NOT NULL,
			price VARCHAR ( 50 ) NOT NULL,
			size VARCHAR ( 255 ) NOT NULL, 
			image TEXT )");
		return $this->db->affected_rows();
	}

	function multiple_insert($table_name,$data)
	{
		$this->db->insert_batch($table_name, $data); 
		return $this->db->insert_id();
	}

	public function run_manual_query($query)
	{
		$query=$this->db->query($query);
		return $this->db->affected_rows();
		
	}
	
}
?>