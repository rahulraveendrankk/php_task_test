<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller 
{
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('Main_model');
        date_default_timezone_set('Asia/Kolkata');
	}
	public function index() 
	{ 

        $data['properties']= $this->Main_model->get_all_data('properties');

        // echo "<pre>";print_r($data['properties']);die; 

		$this->load->view('web/header');
		$this->load->view('web/home',$data);
		$this->load->view('web/footer');
	}

    public function create_table() 
    {
        try{
            $this->Main_model->create_table(); 
            echo "Created successfully";

            redirect('home/insert_data');
        }catch(Exception $e){
            echo "Error Message. ".$e->getMessage();
        }
        
    }

    public function insert_data() 
    {
        $data=array();
        try{
            for ($i=1; $i <= 10; $i++) { 

                $property_name='Property '.$i;
                $price=rand(200,500);
                $size=rand(900,1500);
                $data[]=array('name'=>$property_name,'price'=>$price,'size'=>$size);

            } 

            $this->Main_model->multiple_insert('properties',$data); 

            echo "Data uploaded successfully";

            redirect('');
        }catch(Exception $e){
            echo "Error Message. ".$e->getMessage();
        }
    }
	 

}