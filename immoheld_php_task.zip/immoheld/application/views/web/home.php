	
	<main>
	 
		<!--/carousel-->
 
		<!--/feat-->

		 
		<!-- /container -->
		
		 
		<div class="container "><!-- margin_60_35 -->
			<div class="main_title">
				<h2>Our Properties - Test List</h2>
				<span></span>
				<p><!-- Cum doctus civibus efficiantur in imperdiet deterruisset --></p>
			</div>
			<div class="row small-gutters" id="container" data-sorted="unsorted">
				<?php foreach ($properties as $key => $value) {   ?>
					 
				
				<div class="col-7 col-md-4 col-xl-4 allProperties" item_price="<?php echo $value->price; ?>" item_size="<?php echo $value->size; ?>">
					<div class="grid_item">
						<figure>
							 
							<a href="product-detail-1.html">
								<img class="img-fluid lazy" src="<?php echo base_url(); ?>assets/img/images.png"  alt="" style="height: 250px;"> 
							</a>
							 
						</figure>   
							<h4><?php echo $value->name; ?></h4> 
						<div class="price_box">
							<span class="new_price">Price: £ <?php echo $value->price; ?></span> 
						</div>
						<div class="price_box">
							<span class="new_price">Size: <?php echo $value->size; ?>.sf</span> 
						</div>
						 
					</div>
 
				</div>
			<?php } ?>
			 
				 
			</div>
			<!-- /row -->
		</div>
	 
	</main>
	<!-- /main -->
		
	